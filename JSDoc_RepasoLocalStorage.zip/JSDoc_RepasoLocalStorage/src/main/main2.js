/**
 * @author David García
 * @description Script para la página index2.html
 * @since 23/06/2024
 * @version 1.0
 * @see https://developer.mozilla.org/es/docs/Web/API/Window/localStorage
 */

/**
 * @fileoverview
 * <a id="volver-introduccion" href="index.html">← Volver a Introducción</a>
 */

/**
 * Suma dos números.
 * @param {number} a
 * @param {number} b
 * @returns {number}
 */
function sumar(a, b) {
  return a + b;
}

/**
 * @description Recupera y muestra los datos del usuario almacenados en el localStorage
 * @return {void}
 */
localStorage.removeItem("contadorindex2");

/**
 * @description Recupera y muestra los datos del usuario almacenados en el localStorage
 * @return {void}
 */
function recuperarDatos1() {
  /** @type {HTMLElement} */
  const parrafoResultado = document.getElementById("resultado");

  // leer del navegador el nombreUsuario
  /** @type {string | null} */
  let nombreUsuario = localStorage.getItem("nombre");
  /** @type {string | null} */
  let edadUsuario = localStorage.getItem("edad");

  console.log("Variables, Usuario:", nombreUsuario, "Edad:", edadUsuario);

  /**
   * @description Mostrar en el párrafo el nombre y la edad del usuario
   * @type {string}
   */
  parrafoResultado.innerHTML =
    "Variable --> Nombre: " + nombreUsuario + ", Edad: " + edadUsuario;

  /** @type {HTMLElement}
   */
  const parrafoResultado2 = document.getElementById("resultado2");

  /**
   * @type {Object | null}
   */
  let datos_user = localStorage.getItem("usuarioData");

  /**
   * @description Parsear el objeto JSON recuperado del localStorage
   * @type {Object}
   */
  datos_user = JSON.parse(datos_user); //se ha de parsear para que se trate como objeto

  /**
   * @description Mostrar en consola el objeto recuperado
   * @type {string}
   */
  console.log(
    "Registro de Datos, Usuario:",
    datos_user.nombre,
    "Edad:",
    datos_user.edad
  );

  /**
   * @description Mostrar en el párrafo el nombre y la edad del usuario desde el objeto
   * @type {string}
   */
  parrafoResultado2.innerHTML =
    "Registro --> Nombre: " + datos_user.nombre + ", Edad: " + datos_user.edad;
}
