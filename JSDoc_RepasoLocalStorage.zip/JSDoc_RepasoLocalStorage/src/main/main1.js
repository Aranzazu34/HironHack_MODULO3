/**
 * @author: Pablo Lozano
 * @description: Script para la página index1.html
 * @since: 23/06/2024
 * @version: 1.0
 * @see: https://developer.mozilla.org/es/docs/Web/API/Window/localStorage
 *      https://developer.mozilla.org/es/docs/Web/API/Window/sessionStorage *
 */

/**
 * @fileoverview
 * <a id="volver-introduccion" href="index.html">← Volver a Introducción</a>
 */

/**
 * Suma dos números.
 * @param {number} a
 * @param {number} b
 * @returns {number}
 */
function sumar(a, b) {
  return a + b;
}

// pillar el campo de input
/**
 * @type {HTMLInputElement}
 */
const userInput = document.getElementById("usuario");
/**
 * @type {HTMLInputElement}
 */
const ageInput = document.getElementById("edad");

localStorage.removeItem("contadorindex1");

/**
 * @description Guarda el nombre y la edad del usuario en el localStorage
 * @return {void}
 */
function guardarDato() {
  /**
   * @type {string}
   */
  let nombreUsuario = userInput.value; //pepito
  /**
   * @type {string}
   */
  let edadUsuario = ageInput.value; //34

  console.log("Variables, Usuario:", nombreUsuario, "Edad:", edadUsuario);

  // guardar en el navegador el nombreUsuario
  /**
   * @description Guardar el nombre y la edad del usuario en el localStorage
   */
  localStorage.setItem("nombre", nombreUsuario);

  /**
   * @description Guardar la edad del usuario en el localStorage
   */
  localStorage.setItem("edad", edadUsuario);

  /**
   * @type {Object}
   * @description Objeto para almacenar el registro del usuario
   * @property {string} nombre - Nombre del usuario
   * @property {string} edad - Edad del usuario
   */
  const reg_usuario = { nombre: `${nombreUsuario}`, edad: `${edadUsuario}` };

  /**
   * @description Mostrar en consola el objeto creado
   */
  console.log(
    "Registro de Datos, Usuario:",
    reg_usuario.nombre,
    "Edad:",
    reg_usuario.edad
  );

  /**
   * @description Guardar el objeto en el localStorage como una cadena JSON
   */
  localStorage.setItem("usuarioData", JSON.stringify(reg_usuario));
}
